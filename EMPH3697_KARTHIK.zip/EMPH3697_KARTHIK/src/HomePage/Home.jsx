import { HeaderContainer } from '../Components/HeaderContainer';
import { DiscoverAvailableServicesContainer } from '../Components/DiscoverAvailableServicesContainer';
import { RecommendedServicesContainer } from '../Components/RecommendedServicesContainer';
import { FooterContainer } from '../Components/FooterContainer';

 
const Home = () => {
    return(
        <>
             <HeaderContainer />
      <DiscoverAvailableServicesContainer />
      <RecommendedServicesContainer />
      <FooterContainer />
        </>
    )
}
 
export default Home;